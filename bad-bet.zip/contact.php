<!DOCTYPE html>
<html>
<head>
	<title>BAD BET OFFICIAL</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="band.css">
</head>
<body>
	<ul>
		<li id="home"><a href="band.html">Bad Bet</a></li>
		<li><a href="music.php">Music</a></li>
		<li><a href="vlog.html">On The Street</a></li>
		<li><a href="gig.html">Gigs</a></li>
		<li class="active"><a href="contact.php">Member Login</a></li>
	</ul>

	<h1>LOGIN PAGE</h1>
	<div>
  <form action="http://localhost:8080/path" method="post">
    <label>Username: </label>
    <input type="text" name="username" autofocus /> <br/>
    <label>Password:</label>
    <input type="text" name="password" /> <br/>

    <input type="submit" value="Submit" />
  </form>

  <br/><br/>
  <a href="http://localhost:8080/cs4640s18/examples.confirm?username=john&password=doe rewriting from php to servlet">
  send request (using url rewriting) to servlet</a>
</div>
</body>
</html>
